﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeakInvest.Domain.Models
{
    public class Financial
    {
        public decimal Valor { get; set; }
        public int Parcela { get; set; }
    }
}
